document.getElementById('search-btn').addEventListener('click', () => {
    const query = document.getElementById('search-input').value;
    if (query) {
        searchDocuments(query);
    } else {
        alert('Please enter a search keyword.');
    }
});

function searchDocuments(query) {
    fetch(`http://localhost:5000/search?query=${query}`)
        .then(response => response.json())
        .then(data => displayResults(data))
        .catch(error => console.error('Error fetching search results:', error));
}

function displayResults(results) {
    const resultsContainer = document.getElementById('results-container');
    resultsContainer.innerHTML = '';  // Clear previous results

    if (results && Object.keys(results).length > 0) {
        for (const [docId, sentences] of Object.entries(results)) {
            const resultItem = document.createElement('div');
            resultItem.classList.add('result-item');

            const docTitle = document.createElement('h3');
            docTitle.textContent = `Document: ${docId}`;
            resultItem.appendChild(docTitle);

            sentences.forEach(sentence => {
                const sentenceElement = document.createElement('p');
                sentenceElement.textContent = sentence;
                resultItem.appendChild(sentenceElement);
            });

            resultsContainer.appendChild(resultItem);
        }
    } else {
        const noResults = document.createElement('div');
        noResults.id = 'no-results';
        noResults.textContent = 'No results found for your search.';
        resultsContainer.appendChild(noResults);
    }
}
