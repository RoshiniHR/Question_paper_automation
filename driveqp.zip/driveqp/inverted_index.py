import os
import re
import json
import pytesseract

# Set the Tesseract executable path
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Update with your installation path

from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from collections import defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer
from pdf2image import convert_from_path
from nltk.tokenize import sent_tokenize
import nltk
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.http import MediaFileUpload

# Download required NLTK data files
nltk.download('stopwords')
nltk.download('punkt')

class InvertedIndex:
    def __init__(self):
        self.index = defaultdict(list)
        self.documents = {}
        #stemmer: suffix stripping 
        self.stop_words = set(stopwords.words('english'))
        self.stemmer = PorterStemmer()

    def tokenize(self, text):
        # Tokenization and lowercasing
        tokens = re.findall(r'\b\w+\b', text.lower())
        # Remove stopwords and apply stemming
        return [self.stemmer.stem(token) for token in tokens if token not in self.stop_words]

    def add_document(self, doc_id, text):
        self.documents[doc_id] = text
        tokens = self.tokenize(text)
        for token in tokens:
            if doc_id not in self.index[token]:
                self.index[token].append(doc_id)

    def save_index(self, path):
        with open(path, 'w') as f:
            json.dump({'index': self.index, 'documents': self.documents}, f)

    def load_index(self, path):
        with open(path, 'r') as f:
            data = json.load(f)
            self.index = defaultdict(list, data['index'])
            self.documents = data['documents']

    def search(self, query, num_results=5):
        tokens = self.tokenize(query)
        query_text = ' '.join(tokens)
        relevant_docs = set()
        for token in tokens:
            if token in self.index:
                relevant_docs.update(self.index[token])
        if not relevant_docs:
            return []
        # Calculate TF-IDF scores for relevant documents
        tfidf_vectorizer = TfidfVectorizer()
        tfidf_matrix = tfidf_vectorizer.fit_transform([self.documents[doc_id] for doc_id in relevant_docs])
        # Calculate cosine similarity between query and documents
        query_vector = tfidf_vectorizer.transform([query_text])
        cosine_similarities = tfidf_matrix.dot(query_vector.T).toarray().flatten()
        # Get indices of top matching documents
        top_indices = cosine_similarities.argsort()[-num_results:][::-1]
        return [list(relevant_docs)[i] for i in top_indices]

def read_pdf(file_path):
    text = ''
    images = convert_from_path(file_path)
    for image in images:
        text += pytesseract.image_to_string(image)
    return text

def upload_documents(folder_path):
    inverted_index = InvertedIndex()
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if filename.endswith(".txt"):
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
        elif filename.endswith(".pdf"):
            text = read_pdf(file_path)
        else:
            continue
        inverted_index.add_document(filename, text)
    print(f"Uploaded {len(inverted_index.documents)} documents.")
    return inverted_index

def extract_relevant_sentences(document, query):
    sentences = sent_tokenize(document)
    query_lower = query.lower()
    relevant_sentences = [sentence for sentence in sentences if query_lower in sentence.lower()]
    return relevant_sentences

def query_index(inverted_index, query):
    relevant_document_ids = inverted_index.search(query)
    query_results = {}
    for doc_id in relevant_document_ids:
        relevant_sentences = extract_relevant_sentences(inverted_index.documents[doc_id], query)
        if relevant_sentences:
            query_results[doc_id] = relevant_sentences
    return query_results

def authenticate_drive():
    """Authenticate to Google Drive API."""
    creds = None
    SCOPES = ['https://www.googleapis.com/auth/drive.file']
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return build('drive', 'v3', credentials=creds)

def upload_documents_to_drive(service, folder_id):
    """Upload documents to Google Drive from a local folder."""
    inverted_index = InvertedIndex()
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if filename.endswith(".txt"):
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
        elif filename.endswith(".pdf"):
            text = read_pdf(file_path)
        else:
            continue
        inverted_index.add_document(filename, text)

        # Upload file to Google Drive
        file_metadata = {'name': filename, 'parents': [folder_id]}
        media = MediaFileUpload(file_path, mimetype='application/pdf')
        service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    
    print(f"Uploaded {len(inverted_index.documents)} documents to Google Drive.")
    return inverted_index
    

if __name__ == "__main__":
    # Authenticate and create the Drive service
    drive_service = authenticate_drive()
    
    # Define the folder path on your local machine where the documents are located
    folder_path ="https://drive.google.com/drive/folders/1rNvAEGoIjrWfnyQ2QfUmhu4apV0SNax5?usp=drive_link"  # Change this to your local folder path
    
    # Define your Google Drive folder ID where documents will be uploaded
    drive_folder_id = "1rNvAEGoIjrWfnyQ2QfUmhu4apV0SNax5"  # Change this to your Google Drive folder ID

    # Upload documents and create the inverted index
    inverted_index = upload_documents_to_drive(drive_service, drive_folder_id)

    # Save the inverted index locally
    inverted_index.save_index("inverted_index.json")  # Save index to local

    # Load the index from local
    inverted_index.load_index("inverted_index.json")

    # Perform a search query on indexed documents
    user_query = "applications"  # Example query
    relevant_documents = query_index(inverted_index, user_query)

    # Display relevant results
    print("Relevant sentences for the query '{}':".format(user_query))
    for doc_id, sentences in relevant_documents.items():
        print("Document ID:", doc_id)
        for sentence in sentences:
            print(" -", sentence)
        print("-" * 80)
