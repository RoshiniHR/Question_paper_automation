import os
from flask import Flask, request, redirect, url_for, render_template
from inverted_index import upload_documents, query_index, read_pdf, InvertedIndex  # Import from inverted_index.py

# Initialize the Flask application
app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = './uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    files = request.files.getlist('files')
    for file in files:
        if file:
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))
    return redirect(url_for('home'))

@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query')
    inverted_index = upload_documents(app.config['UPLOAD_FOLDER'])  # Use the function from inverted_index.py
    results = query_index(inverted_index, query)
    return render_template('result.html', query=query, results=results)

if __name__ == '__main__':
    app.run(debug=True)
